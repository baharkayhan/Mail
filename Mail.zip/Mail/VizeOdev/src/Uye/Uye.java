package Uye;

public class Uye {
    public String ad;
    public String soyad;
    public String email;
}
