package Uye;

//üye tipini ayırt etmek için kullanılan enum yapısı
public enum UyeTipi {
    Elit,
    Genel
}