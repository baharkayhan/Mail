



import Islemler.MailIslemleri;
import Islemler.UyelikIslemleri;
import Uye.Uye;
import Uye.UyeTipi;


import java.io.*;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) throws IOException {
        uygulamayiBaslat();
    }


    //uygulamayı başlatan method
    public static String uygulamayiBaslat() throws IOException {
        Uye uyeBilgileri;
        UyelikIslemleri uyelikIslemleri;
        int tercih = anaMenuCagir();

        while (tercih == 0) {
            tercih = anaMenuCagir();  //tercihimiz 1,2,3 değerlerinden farklıysa yeniden ana menü çağırtılır
        }

        switch (tercih) {
            case 1:               //elit uye ekleme işlemi
                uyeBilgileri = uyeBilgileriniAl();
                uyelikIslemleri = new UyelikIslemleri(uyeBilgileri);
                uyelikIslemleri.uyeEkle(UyeTipi.Elit);

                break;

            case 2:                 //genel uye ekleme işlemi
                uyeBilgileri = uyeBilgileriniAl();
                uyelikIslemleri = new UyelikIslemleri(uyeBilgileri);
                uyelikIslemleri.uyeEkle(UyeTipi.Genel);
                break;

            case 3:                 //mail gönderme işlemi
                mailGonderMenuCagir();
                break;
        }

        System.out.println("İşleme Devam etmek istiyor musunuz ? (E/H)");
        Scanner scanner = new Scanner(System.in);
        String devamTercih = scanner.nextLine();

        while (devamTercih.equals("E") || devamTercih.equals("e")) {
            devamTercih = uygulamayiBaslat();           //yeni bir işlem daha yapılmak isteniyorsa menu bu methodla yeniden çağırılır
        }
        return devamTercih;                     //tercih işlemi return edilir
    }


    //ugulama başlatıldıktan sonra ilk (ana) menüyü çağıran method
    public static int anaMenuCagir() {
        System.out.println("1- Elit üye ekleme");
        System.out.println("2- Genel Üye ekleme");
        System.out.println("3- Mail Gönderme");
        Scanner scanner = new Scanner(System.in);
        try {
            int tercih = 0;
            System.out.print("Tercih: ");
            tercih = scanner.nextInt();
            if (!(tercih == 1 || tercih == 2 || tercih == 3)) {
                System.out.println("Yanlış Menü Seçimi.");              //1,2 veya 3 değerinden başka bir sayı girilirse o değeri return edilir
                return 0;
            }
            return tercih;
        } catch (Exception ex) {
            System.out.println("Yanlış Menü Seçimi.");              //Burada integer bir değer dışında bir değer girilirse 0 değeri return edilir
            return 0;
        }

    }

    //ana menude 3 seçilerek mail gönderme işlemi  yapan method
    public static void mailGonderMenuCagir() {
        int tercih = altMenuCagir();                //kimlere mail gönderileceğini seçmek için alt menü çağırılır

        while (tercih == 0) {
            tercih = altMenuCagir();
        }

        MailIslemleri mailIslemleri = new MailIslemleri();
        switch (tercih) {
            case 1:
                mailIslemleri.mailGonder(UyeTipi.Elit);             //elit üye seçimi yapılırsa
                break;

            case 2:
                mailIslemleri.mailGonder(UyeTipi.Genel);            //genel üye seçimi yapılırsa
                break;

            case 3:
                mailIslemleri.tumuyelereMailGonder();               //tüm üyeler seçilirse
                break;
        }
    }

    //ana menüde mail gönderme işlemi seçilirse kimlere gönderileceğine karar verdirten alt menü
    public static int altMenuCagir() {
        System.out.println("1- Elit üyelere Mail");
        System.out.println("2- Genel Üyelere Mail");
        System.out.println("3- Tüm Üyelere");
        Scanner scanner = new Scanner(System.in);

        try {
            int tercih = 0;
            System.out.print("Tercih: ");
            tercih = scanner.nextInt();
            if (!(tercih == 1 || tercih == 2 || tercih == 3)) {
                System.out.println("Yanlış Menü Seçimi!Tekrar deneyiniz.");         //1,2 veya 3 değerinden başka bir sayı girilirse o değeri return edilir
                return 0;
            }

            return tercih;
        } catch (Exception ex) {
            System.out.println("Yanlış Menü Seçimi!Tekrar deneyiniz.");             //Burada integer bir değer dışında bir değer girilirse 0 değeri return edilir
            return 0;
        }

    }


    //üye bilgilerinin alınndığı method
    public static Uye uyeBilgileriniAl() {
        Uye uye = new Uye();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Uye.Uye Adi:");
        uye.ad = scanner.nextLine();

        System.out.print("Uye.Uye Soyadi:");
        uye.soyad = scanner.nextLine();

        System.out.print("Uye.Uye Email:");
        uye.email = scanner.nextLine();

        return uye;
    }
}

/*
class Uye.Uye {
    public String ad;
    public String soyad;
    public String email;
}
*/

/*//üye tipini ayırt etmek için kullanılan enum yapısı
enum Uye.UyeTipi {
    Elit,
    Genel
}*/

/*//dosya işlemlerinin gerçekleştirildiği class
class Islemler.DosyaIslemleri {
    File currentDirectory = new File(System.getProperty("user.dir"));
    String mevcutDosyaYolu = currentDirectory.getAbsolutePath();
    String dosyaYolu = mevcutDosyaYolu + "\\src\\Kullanıcılar.txt";
    File file = new File(dosyaYolu);  //dosyanın konumu
    FileWriter fw;

    {
        try {
            fw = new FileWriter(file, true);        // true, dosyayı yazma modunda açar
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    BufferedWriter bw = new BufferedWriter(fw);
    BufferedReader br;

    {
        try {
            br = new BufferedReader(new FileReader(file));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    FileWriter fileWriter;

    // Dosyaya yazma işlemi için gerekli nesnelerin oluşturulması
    {
        try {
            fileWriter = new FileWriter(dosyaYolu, true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //dosyayı ikiletmemek için temizler
    public void dosyayiTemizle() throws IOException {
        File file = new File(dosyaYolu);
        FileWriter writer = new FileWriter(file);
        writer.write("");
        writer.close();
    }

    public void elitUyeEkle(Uye.Uye uye) throws RuntimeException, IOException {
        FileWriter fileWriter = new FileWriter(dosyaYolu, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        PrintWriter printWriter = new PrintWriter(bufferedWriter);
        StringBuilder finalBuilder = new StringBuilder();           //dosyada bulunan ve eklenen verileri içinde tutar
        Scanner scanner = new Scanner(new File(dosyaYolu));

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            finalBuilder.append(line);
            finalBuilder.append("\n");

            if (line.contains("#ELÝT ÜYELER  #") ) {
                finalBuilder.append(uye.ad + "\t" + uye.soyad + "\t" + uye.email);
                finalBuilder.append("\n");
            }
        }

        dosyayiTemizle();
        fileWriter.write(finalBuilder.toString());


        if (printWriter != null) printWriter.close();

        if (bufferedWriter != null) {
            bufferedWriter.close();
        }

        if (fileWriter != null) {
            fileWriter.close();
        }

    }


    public void genelUyeEkle(Uye.Uye uye) throws IOException {
        FileWriter fileWriter = new FileWriter(dosyaYolu, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        PrintWriter printWriter = new PrintWriter(bufferedWriter);
        StringBuilder finalBuilder = new StringBuilder();           //dosyada bulunan ve eklenen verileri içinde tutar
        Scanner scanner = new Scanner(new File(dosyaYolu));

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            finalBuilder.append(line);
            finalBuilder.append("\n");

            if (line.contains("#GENEL ÜYELER")) {
                finalBuilder.append(uye.ad + "\t" + uye.soyad + "\t" + uye.email);
                finalBuilder.append("\n");
            }
        }

        dosyayiTemizle();
        fileWriter.write(finalBuilder.toString());


        if (printWriter != null) printWriter.close();

        if (bufferedWriter != null) {
            bufferedWriter.close();
        }

        if (fileWriter != null) {
            fileWriter.close();
        }
    }


    //elit üyeleri bir liste olarak dönen method
    public List<Uye.Uye> elitUyeleriGetir() {
        boolean elitUyeBasladimi = false;
        List<Uye.Uye> uyeler = new ArrayList<>();
        Path elitDosyaYolu;
        elitDosyaYolu = Paths.get(file.toURI());
        try (BufferedReader reader = Files.newBufferedReader(elitDosyaYolu)) {
            String line = null;
            while ((line = reader.readLine()) != null) {

                if (line.equals("#ELÝT ÜYELER  #")) {
                    elitUyeBasladimi = true;        //#ELÝT ÜYELER  # etiketi okununca değer true olarak değiştirilir
                    continue;
                }

                if (line.equals("#GENEL ÜYELER")) {
                    return uyeler;
                }

                if (elitUyeBasladimi && !line.isEmpty()) {      //#ELÝT ÜYELER  # etiketi okunuduysa ve line boş değilse uye okuma işlemi başlar
                    Uye.Uye uye = new Uye.Uye();
                    String[] tokens = line.split("\\s+");
                    uye.ad = tokens[0];
                    uye.soyad = tokens[1];
                    uye.email = tokens[2];
                    uyeler.add(uye);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        return uyeler;
    }


    //genel üyeleri bir liste olarak dönen method
    public List<Uye.Uye> genelUyeleriGetir() {
        boolean genelUyeBasladimi = false;

        List<Uye.Uye> uyeler = new ArrayList<>();
        Path genelDosyaYolu;
        genelDosyaYolu = Paths.get(file.toURI());
        try (BufferedReader reader = Files.newBufferedReader(genelDosyaYolu)) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.equals("#GENEL ÜYELER")) {
                    genelUyeBasladimi = true;
                    continue;
                }


                if (genelUyeBasladimi && !line.isEmpty()) {             //#GENEL ÜYELER etiketi okunuduysa ve line boş değilse uye okuma işlemi başlar
                    Uye.Uye uye = new Uye.Uye();
                    String[] tokens = line.split("\\s+");
                    uye.ad = tokens[0];
                    uye.soyad = tokens[1];
                    uye.email = tokens[2];
                    uyeler.add(uye);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return uyeler;
    }
}*/

/*//mail işlemlerinin gerçekleştirildiği class
class Islemler.MailIslemleri {


    private void smtpMailGonder(String mailAliciları) {

        // E-posta hesap bilgileri tanımlanır.
        final String username = "deneme@test.com";
        final String password = "test";

        // E-posta göndermek için gerekli ayarlar yapılır.
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.office365.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.trust", "smtp.office365.com");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        // Session nesnesi oluşturulur ve oturum açma işlemi gerçekleştirilir.
        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            // Mesaj nesnesi oluşturulur ve e-posta ayrıntıları belirlenir.
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("deneme@test.com"));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(mailAliciları));
            message.setSubject("Testing Subject");
            message.setText("Dear Recipient,"
                    + "\n\n This is a test email from Java!");

            // E-posta gönderme işlemi gerçekleştirilir ve başarılı bir şekilde gönderildiği kontrol edilir.
           Transport.send(message);
            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            throw new RuntimeException(e);      // E-posta gönderme işlemi başarısız olursa, bir hata oluşmuş demektir. Bu nedenle hata fırlatılır.
        }
    }

    public void mailGonder(Uye.UyeTipi uyeTipi) {
        Islemler.DosyaIslemleri dosyaIslemleri = new Islemler.DosyaIslemleri();
        List<Uye.Uye> mailAlicilari = new ArrayList<>();

        // Uye.UyeTipi'ne göre gerekli mail alıcılarını elde etmek için uygun Islemler.DosyaIslemleri sınıfındaki metot çağrılır
        if (uyeTipi == Uye.UyeTipi.Elit) {
            mailAlicilari = dosyaIslemleri.elitUyeleriGetir();
        } else if (uyeTipi == Uye.UyeTipi.Genel) {
            mailAlicilari = dosyaIslemleri.genelUyeleriGetir();
        }

        String alicilar = "";

        // Tüm mail alıcılarını bir string olarak topla
        for (Uye.Uye uye : mailAlicilari) {
            alicilar = alicilar + uye.email + ",";
        }

        // Elde edilen mail alıcılarına e-posta göndermek için smtpMailGonder metodu çağrılır
        smtpMailGonder(alicilar);
    }

    public void tumuyelereMailGonder() {
        String alicilar = "";

        // Islemler.DosyaIslemleri sınıfından bir nesne oluşturuluyor.
        Islemler.DosyaIslemleri dosyaIslemleri = new Islemler.DosyaIslemleri();

        // Elit üyelerin e-posta adresleri dosyadan okunarak bir listeye ekleniyor.
        List<Uye.Uye> mailAlicilari = dosyaIslemleri.elitUyeleriGetir();

        // Genel üyelerin e-posta adresleri dosyadan okunarak bir listeye ekleniyor.
        List<Uye.Uye> genelMailAlicilari = dosyaIslemleri.genelUyeleriGetir();

        // Genel üyelerin listesi elit üyelerin listesine ekleniyor.
        mailAlicilari.addAll(genelMailAlicilari);

        // E-posta gönderilecek tüm üyelerin e-posta adresleri virgülle ayrılarak bir string değişkene atanıyor.
        for (Uye.Uye uye : mailAlicilari) {
            alicilar = alicilar + uye.email + ",";
        }

        smtpMailGonder(alicilar);           // SMTP sunucusu üzerinden e-postalar gönderiliyor.
    }
}*/
/*

// Islemler.UyelikIslemleri sınıfı, yeni üyelerin kaydedilmesi işlemlerini yürütür.
class Islemler.UyelikIslemleri extends Uye.Uye {
    public Uye.Uye uye;

    public Islemler.UyelikIslemleri(Uye.Uye _uye) {           // Yapıcı metod, yeni eklenen üyenin bilgilerini alır.
        this.uye = _uye;
    }

    // Yeni bir üye ekler.
    public void uyeEkle(Uye.UyeTipi uyeTipi) throws IOException {
        Islemler.DosyaIslemleri dosyaIslemleri = new Islemler.DosyaIslemleri();

        // Üye tipine göre dosya işlemleri yapılır.
        if (uyeTipi == Uye.UyeTipi.Elit) {
            dosyaIslemleri.elitUyeEkle(uye);


        } else if (uyeTipi == Uye.UyeTipi.Genel) {
            dosyaIslemleri.genelUyeEkle(uye);

        } else {                // Bilinmeyen üye tipi hata mesajı verilir.
            System.out.println("Bilinmeyen Uye.Uye Tipi.");
        }
    }
}
*/




