package Islemler;
import Uye.Uye;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//dosya işlemlerinin gerçekleştirildiği class
public class DosyaIslemleri {
    File currentDirectory = new File(System.getProperty("user.dir"));
    String mevcutDosyaYolu = currentDirectory.getAbsolutePath();
    String dosyaYolu = mevcutDosyaYolu + "\\src\\Kullanıcılar.txt";
    File file = new File(dosyaYolu);  //dosyanın konumu
    FileWriter fw;

    {
        try {
            fw = new FileWriter(file, true);        // true, dosyayı yazma modunda açar
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    BufferedWriter bw = new BufferedWriter(fw);
    BufferedReader br;

    {
        try {
            br = new BufferedReader(new FileReader(file));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    FileWriter fileWriter;

    // Dosyaya yazma işlemi için gerekli nesnelerin oluşturulması
    {
        try {
            fileWriter = new FileWriter(dosyaYolu, true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //dosyayı ikiletmemek için temizler
    public void dosyayiTemizle() throws IOException {
        File file = new File(dosyaYolu);
        FileWriter writer = new FileWriter(file);
        writer.write("");
        writer.close();
    }

    public void elitUyeEkle(Uye uye) throws RuntimeException, IOException {
        FileWriter fileWriter = new FileWriter(dosyaYolu, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        PrintWriter printWriter = new PrintWriter(bufferedWriter);
        StringBuilder finalBuilder = new StringBuilder();           //dosyada bulunan ve eklenen verileri içinde tutar
        Scanner scanner = new Scanner(new File(dosyaYolu));

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            finalBuilder.append(line);
            finalBuilder.append("\n");

            if (line.contains("#ELÝT ÜYELER  #") ) {
                finalBuilder.append(uye.ad + "\t" + uye.soyad + "\t" + uye.email);
                finalBuilder.append("\n");
            }
        }

        dosyayiTemizle();
        fileWriter.write(finalBuilder.toString());


        if (printWriter != null) printWriter.close();

        if (bufferedWriter != null) {
            bufferedWriter.close();
        }

        if (fileWriter != null) {
            fileWriter.close();
        }

    }


    public void genelUyeEkle(Uye uye) throws IOException {
        FileWriter fileWriter = new FileWriter(dosyaYolu, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        PrintWriter printWriter = new PrintWriter(bufferedWriter);
        StringBuilder finalBuilder = new StringBuilder();           //dosyada bulunan ve eklenen verileri içinde tutar
        Scanner scanner = new Scanner(new File(dosyaYolu));

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            finalBuilder.append(line);
            finalBuilder.append("\n");

            if (line.contains("#GENEL ÜYELER")) {
                finalBuilder.append(uye.ad + "\t" + uye.soyad + "\t" + uye.email);
                finalBuilder.append("\n");
            }
        }

        dosyayiTemizle();
        fileWriter.write(finalBuilder.toString());


        if (printWriter != null) printWriter.close();

        if (bufferedWriter != null) {
            bufferedWriter.close();
        }

        if (fileWriter != null) {
            fileWriter.close();
        }
    }


    //elit üyeleri bir liste olarak dönen method
    public List<Uye> elitUyeleriGetir() {
        boolean elitUyeBasladimi = false;
        List<Uye> uyeler = new ArrayList<>();
        Path elitDosyaYolu;
        elitDosyaYolu = Paths.get(file.toURI());
        try (BufferedReader reader = Files.newBufferedReader(elitDosyaYolu)) {
            String line = null;
            while ((line = reader.readLine()) != null) {

                if (line.equals("#ELÝT ÜYELER  #")) {
                    elitUyeBasladimi = true;        //#ELÝT ÜYELER  # etiketi okununca değer true olarak değiştirilir
                    continue;
                }

                if (line.equals("#GENEL ÜYELER")) {
                    return uyeler;
                }

                if (elitUyeBasladimi && !line.isEmpty()) {      //#ELÝT ÜYELER  # etiketi okunuduysa ve line boş değilse uye okuma işlemi başlar
                    Uye uye = new Uye();
                    String[] tokens = line.split("\\s+");
                    uye.ad = tokens[0];
                    uye.soyad = tokens[1];
                    uye.email = tokens[2];
                    uyeler.add(uye);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        return uyeler;
    }


    //genel üyeleri bir liste olarak dönen method
    public List<Uye> genelUyeleriGetir() {
        boolean genelUyeBasladimi = false;

        List<Uye> uyeler = new ArrayList<>();
        Path genelDosyaYolu;
        genelDosyaYolu = Paths.get(file.toURI());
        try (BufferedReader reader = Files.newBufferedReader(genelDosyaYolu)) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.equals("#GENEL ÜYELER")) {
                    genelUyeBasladimi = true;
                    continue;
                }


                if (genelUyeBasladimi && !line.isEmpty()) {             //#GENEL ÜYELER etiketi okunuduysa ve line boş değilse uye okuma işlemi başlar
                    Uye uye = new Uye();
                    String[] tokens = line.split("\\s+");
                    uye.ad = tokens[0];
                    uye.soyad = tokens[1];
                    uye.email = tokens[2];
                    uyeler.add(uye);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return uyeler;
    }
}