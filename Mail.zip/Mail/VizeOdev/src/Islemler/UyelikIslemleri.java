package Islemler;
import Uye.Uye;
import Uye.UyeTipi;


import java.io.IOException;

// Islemler.UyelikIslemleri sınıfı, yeni üyelerin kaydedilmesi işlemlerini yürütür.
public class UyelikIslemleri extends Uye {
    public Uye uye;

    public UyelikIslemleri(Uye _uye) {           // Yapıcı metod, yeni eklenen üyenin bilgilerini alır.
        this.uye = _uye;
    }

    // Yeni bir üye ekler.
    public void uyeEkle(UyeTipi uyeTipi) throws IOException {
        DosyaIslemleri dosyaIslemleri = new DosyaIslemleri();

        // Üye tipine göre dosya işlemleri yapılır.
        if (uyeTipi == UyeTipi.Elit) {
            dosyaIslemleri.elitUyeEkle(uye);


        } else if (uyeTipi == UyeTipi.Genel) {
            dosyaIslemleri.genelUyeEkle(uye);

        } else {                // Bilinmeyen üye tipi hata mesajı verilir.
            System.out.println("Bilinmeyen Uye.Uye Tipi.");
        }
    }
}
