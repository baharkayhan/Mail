package Islemler;
import Uye.Uye;
import Uye.UyeTipi;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

//mail işlemlerinin gerçekleştirildiği class
public class MailIslemleri {


    private void smtpMailGonder(String mailAliciları) {

        // E-posta hesap bilgileri tanımlanır.
        final String username = "deneme@test.com";
        final String password = "deneme";

        // E-posta göndermek için gerekli ayarlar yapılır.
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.office365.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.trust", "smtp.office365.com");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        // Session nesnesi oluşturulur ve oturum açma işlemi gerçekleştirilir.
        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            // Mesaj nesnesi oluşturulur ve e-posta ayrıntıları belirlenir.
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("deneme@test.com"));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(mailAliciları));
            message.setSubject("Testing Subject");
            message.setText("Dear Recipient,"
                    + "\n\n This is a test email from Java!");

            // E-posta gönderme işlemi gerçekleştirilir ve başarılı bir şekilde gönderildiği kontrol edilir.
            Transport.send(message);
            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            throw new RuntimeException(e);      // E-posta gönderme işlemi başarısız olursa, bir hata oluşmuş demektir. Bu nedenle hata fırlatılır.
        }
    }

    public void mailGonder(UyeTipi uyeTipi) {
        DosyaIslemleri dosyaIslemleri = new DosyaIslemleri();
        List<Uye> mailAlicilari = new ArrayList<>();

        // Uye.UyeTipi'ne göre gerekli mail alıcılarını elde etmek için uygun Islemler.DosyaIslemleri sınıfındaki metot çağrılır
        if (uyeTipi == UyeTipi.Elit) {
            mailAlicilari = dosyaIslemleri.elitUyeleriGetir();
        } else if (uyeTipi == UyeTipi.Genel) {
            mailAlicilari = dosyaIslemleri.genelUyeleriGetir();
        }

        String alicilar = "";

        // Tüm mail alıcılarını bir string olarak topla
        for (Uye uye : mailAlicilari) {
            alicilar = alicilar + uye.email + ",";
        }

        // Elde edilen mail alıcılarına e-posta göndermek için smtpMailGonder metodu çağrılır
        smtpMailGonder(alicilar);
    }

    public void tumuyelereMailGonder() {
        String alicilar = "";

        // Islemler.DosyaIslemleri sınıfından bir nesne oluşturuluyor.
        DosyaIslemleri dosyaIslemleri = new DosyaIslemleri();

        // Elit üyelerin e-posta adresleri dosyadan okunarak bir listeye ekleniyor.
        List<Uye> mailAlicilari = dosyaIslemleri.elitUyeleriGetir();

        // Genel üyelerin e-posta adresleri dosyadan okunarak bir listeye ekleniyor.
        List<Uye> genelMailAlicilari = dosyaIslemleri.genelUyeleriGetir();

        // Genel üyelerin listesi elit üyelerin listesine ekleniyor.
        mailAlicilari.addAll(genelMailAlicilari);

        // E-posta gönderilecek tüm üyelerin e-posta adresleri virgülle ayrılarak bir string değişkene atanıyor.
        for (Uye uye : mailAlicilari) {
            alicilar = alicilar + uye.email + ",";
        }

        smtpMailGonder(alicilar);           // SMTP sunucusu üzerinden e-postalar gönderiliyor.
    }
}